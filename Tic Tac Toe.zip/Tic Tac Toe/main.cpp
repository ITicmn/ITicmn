#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int player=1,press[9]={0,0,0,0,0,0,0,0};
    int l,n,i,j,x=0;
    char b[3][3],s[3][3];
    srand(time(NULL)+getpid());
    cout<<"Welcome to Tic Tac Toe!"<<endl;
    system("pause");
    system("cls");
    cout<<"Please play with you numpad"<<endl;
    cout<<" 7 | 8 | 9 "<<endl;
    cout<<"---+---+---"<<endl;
    cout<<" 4 | 5 | 6 "<<endl;
    cout<<"---+---+---"<<endl;
    cout<<" 1 | 2 | 3 "<<endl;
    cout<<"Ready?"<<endl;
    system("pause");
    system("cls");
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            b[i][j]=95;
            cout<<b[i][j]<<ends;
        }
    }
    start:
    l=rand()%(3-0)+0;
    n=rand()%(3-0)+0;
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            if (b[l][n]!=95)
            {
                goto start;
            }
        }
    }
    b[l][n]=79;
    system("cls");
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            cout<<b[i][j]<<ends;
        }
        if (i<2)
        {
            cout<<endl;
        }
    }
    if (b[0][0]==79&&b[1][0]==79&&b[2][0]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[1][0]==88&&b[2][0]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][1]==79&&b[1][1]==79&&b[2][1]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][1]==88&&b[1][1]==88&&b[2][1]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][2]==79&&b[1][2]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][2]==88&&b[1][2]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][0]==79&&b[0][1]==79&&b[0][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[0][1]==88&&b[0][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[1][0]==79&&b[1][1]==79&&b[1][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[1][0]==88&&b[1][1]==88&&b[1][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[2][0]==79&&b[2][1]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[2][0]==88&&b[2][1]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][0]==79&&b[1][1]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[1][1]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][2]==79&&b[1][1]==79&&b[2][0]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][2]==88&&b[1][1]==88&&b[2][0]==88)//
    {
        x=1;
        goto ed;
    }
    if (b[0][0]!=95&&b[1][0]!=95&&b[2][0]!=95&&b[0][1]!=95&&b[1][1]!=95&&b[2][1]!=95&&b[0][2]!=95&&b[1][2]!=95&&b[2][2]!=95)
    {
        x=2;
        goto ed;
    }
    while (player!=0)
    {
        select:
        if (GetKeyState(103) & 0x8000)
        {
            if (press[0]!=0)
            {
                goto select;
            }
            b[0][0]=88;
            press[0]=press[0]+1;
            break;
        }
        else if (GetKeyState(104) & 0x8000)
        {
            if (press[1]!=0)
            {
                goto select;
            }
            b[0][1]=88;
            press[1]=press[1]+1;
            break;
        }
        else if (GetKeyState(105) & 0x8000)
        {
            if (press[2]!=0)
            {
                goto select;
            }
            b[0][2]=88;
            press[2]=press[2]+1;
            break;
        }
        else if (GetKeyState(100) & 0x8000)
        {
            if (press[3]!=0)
            {
                goto select;
            }
            b[1][0]=88;
            press[3]=press[3]+1;
            break;
        }
        else if (GetKeyState(101) & 0x8000)
        {
            if (press[4]!=0)
            {
                goto select;
            }
            b[1][1]=88;
            press[4]=press[4]+1;
            break;
        }
        else if (GetKeyState(102) & 0x8000)
        {
            if (press[5]!=0)
            {
                goto select;
            }
            b[1][2]=88;
            press[5]=press[5]+1;
            break;
        }
        else if (GetKeyState(97) & 0x8000)
        {
            if (press[6]!=0)
            {
                goto select;
            }
            b[2][0]=88;
            press[6]=press[6]+1;
            break;
        }
        else if (GetKeyState(98) & 0x8000)
        {
            if (press[7]!=0)
            {
                goto select;
            }
            b[2][1]=88;
            press[7]=press[7]+1;
            break;
        }
        else if (GetKeyState(99) & 0x8000)
        {
            if (press[8]!=0)
            {
                goto select;
            }
            b[2][2]=88;
            press[8]=press[8]+1;
            break;
        }
    }
    system("cls");
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            cout<<b[i][j]<<ends;
        }
        if (i<2)
        {
            cout<<endl;
        }
    }
    if (b[0][0]==79&&b[1][0]==79&&b[2][0]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[1][0]==88&&b[2][0]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][1]==79&&b[1][1]==79&&b[2][1]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][1]==88&&b[1][1]==88&&b[2][1]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][2]==79&&b[1][2]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][2]==88&&b[1][2]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][0]==79&&b[0][1]==79&&b[0][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[0][1]==88&&b[0][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[1][0]==79&&b[1][1]==79&&b[1][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[1][0]==88&&b[1][1]==88&&b[1][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[2][0]==79&&b[2][1]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[2][0]==88&&b[2][1]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][0]==79&&b[1][1]==79&&b[2][2]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][0]==88&&b[1][1]==88&&b[2][2]==88)//
    {
        x=1;
        goto ed;
    }
    else if (b[0][2]==79&&b[1][1]==79&&b[2][0]==79)//
    {
        x=3;
        goto ed;
    }
    else if (b[0][2]==88&&b[1][1]==88&&b[2][0]==88)//
    {
        x=1;
        goto ed;
    }
    if (b[0][0]!=95&&b[1][0]!=95&&b[2][0]!=95&&b[0][1]!=95&&b[1][1]!=95&&b[2][1]!=95&&b[0][2]!=95&&b[1][2]!=95&&b[2][2]!=95)
    {
        x=2;
        goto ed;
    }
    goto start;
    ed:
    if (x==1)
    {
        system("cls");
        cout<<"Player Wins"<<endl;
    }
    else if (x==2)
    {
        system("cls");
        cout<<"Tie"<<endl;
    }
    else if (x==3)
    {
        system("cls");
        cout<<"AI Wins"<<endl;
    }
    Sleep(1000000);
    return 0;
}
/*
O=79
X=88
*/
