#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int j=1;
    float a,b,c,d;
    input:
    system("cls");
    cout<<"Please input your Unary quadratic equation in order ax*x+bx+c=d"<<endl;
    cin>>a>>b>>c>>d;
    if ((b*b-4*a*(c-d))<0)
    {
        system("cls");
        cout<<"X does not exist"<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    else if ((b*b-4*a*(c-d))==0)
    {
        system("cls");
        cout<<"x="<<-1*b/(2*a)<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    else if ((b*b-4*a*(c-d))>0)
    {
        system("cls");
        cout<<"x="<<-1*b+pow(b*b-4*a*(c-d),0.5)/(2*a)<<" or "<<-1*b-pow(b*b-4*a*(c-d),0.5)/(2*a)<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    return 0;
}
