#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    string t,ans;
    string over[30],x[30]={"moisture","compete","analysis","algorithm","quart","vocabulary","scythe","cipher","program","formula","application","desktop","library","laboratory","software","unity","custom","superstition","suspicious","offensive","radius","hesitate","monitor","exclusive","construct","photograph","judgement","illustrator","diagonal","veteran"};
    int i,n,hit=0,wrong=0;
    srand(time(NULL)+getpid());
    cout<<"Welcome to Vocab Practice!"<<endl;
    system("pause");
    system("cls");
    cout<<"You'll get a word with blanks..."<<endl;
    cout<<"Type in the completely and correct word."<<endl;
    system("pause");
    system("cls");
    while (hit!=29)
    {
        system("cls");
        random:
        n=rand()%(31-1)+1;
        int p[x[n].length()];
        for (i=0;i<hit;i++)
        {
            if (x[n]==over[i])
            {
                goto random;
            }
        }
        t=x[n];
        over[hit]=x[n];
        hit=hit+1;
        if (x[n].length()<=5)
        {
            for (i=0;i<2;i++)
            {
                p[i]=rand()%(x[n].length()-2)+1;
                t[p[i]]=95;
            }
        }
        else if (x[n].length()>5 && x[n].length()<7)
        {
            for (i=0;i<3;i++)
            {
                p[i]=rand()%(x[n].length()-2)+1;
                t[p[i]]=95;
            }
        }
        else if (x[n].length()>=7 && x[n].length()<9)
        {
            for (i=0;i<4;i++)
            {
                p[i]=rand()%(x[n].length()-2)+1;
                t[p[i]]=95;
            }
        }
        else
        {
            for (i=0;i<5;i++)
            {
                p[i]=rand()%(x[n].length()-2)+1;
                t[p[i]]=95;
            }
        }
        cout<<t<<endl;
        cin>>ans;
        if (ans==x[n])
        {
            cout<<"correct!Well done!"<<endl;
        }
        else if (ans!=x[n])
        {
            wrong=wrong+1;
            cout<<"wrong!The answer is:"<<x[n]<<endl;
        }
        Sleep(2000);
    }
    cout<<"You got "<<wrong<<" wrong"<<endl;
    return 0;
}
