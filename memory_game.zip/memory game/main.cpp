#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int n,m,i,t,j,l,score=0,correct=0,w=0,g;
    cout<<"Welcome to memory game"<<endl;
    system("pause");
    system("cls");
    first:
    cout<<"Choose the difficulty:"<<endl;
    cout<<"       1.<Easy>            2.<Normal>            3.<Hard>            4.<Impossible>"<<endl;
    cout<<"       For babies          Totally normal        Just Hard           IMPOSSIBLE!!! "<<endl;
    input:
    cin>>n;
    srand(time(NULL)+getpid());
    if (n==1)
    {
        m=3;
        t=2000;
        g=1;
    }
    else if (n==2)
    {
        m=5;
        t=1500;
        g=2;
    }
    else if (n==3)
    {
        m=7;
        t=1000;
        g=3;
    }
    else if (n==4)
    {
        m=12;
        t=500;
        g=0;
    }
    else
    {
        goto input;
    }
    system("cls");
    cout<<"You'll see a bunch of numbers..."<<endl;
    Sleep(1000);
    cout<<"Remember it,and after it's gone..."<<endl;
    Sleep(1000);
    cout<<"Type them out"<<endl;
    Sleep(1000);
    system("pause");
    system("cls");
    cout<<"If you guest wrong over a specific amount,you fail"<<endl;
    Sleep(1000);
    cout<<"If you attempt to complete it,you'll restart"<<endl;
    Sleep(1000);
    cout<<"Are you ready?"<<endl;
    system("pause");
    system("cls");
    int a[m],b[m];
    start:
    for (i=0;i<m;i++)
    {
        a[i]=rand()%(10-1)+1;
        cout<<a[i]<<" "<<flush;
    }
    Sleep(t);
    system("cls");
    for (j=0;j<m;j++)
    {
        cin>>b[j];
    }
    for (l=0;l<m;l++)
    {
        if (b[l]==a[l])
        {
            score=score+1;
        }
        else
        {
            cout<<b[l]<<"Wrong! Correct:"<<a[l]<<endl;
            w=w+1;
        }
    }
    if (w>g)
    {
        cout<<"You Fail!"<<endl;
        cout<<"correct:"<<correct<<endl;
        cout<<"Final Score:"<<score<<flush;
        Sleep(3000);
        system("cls");
        for (i=5;i>=1;i--)
        {
            cout<<"Press SPACE To Restart---"<<i<<endl;
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                system("cls");
                goto first;
            }
            Sleep(1000);
            system("cls");
        }
        return 0;
    }
    else
    {
        correct=correct+1;
        cout<<"Nice Job!"<<endl;
        cout<<"Score:"<<score<<endl;
        Sleep(2000);
        system("cls");
        goto start;
    }

    return 0;
}
