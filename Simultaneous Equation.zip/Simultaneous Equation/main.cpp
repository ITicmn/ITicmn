#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int j=1;
    float a,b,c,d,e,f;
    //aX+bY=c
    //dX+eY=f
    input:
    system("cls");
    cout<<"Please input aX+bY=c & dX+eY=f"<<endl;
    cin>>a>>b>>c>>d>>e>>f;
    if (a/d==b/e&&a/d==c/f&&b/e==c/f)
    {
        system("cls");
        cout<<"They're the same line"<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    else if (a/d==b/e&&a/d!=c/f&&b/e!=c/f)
    {
        system("cls");
        cout<<"They have no connection"<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    else if (a==0&b==0||d==0&&e==0)
    {
        system("cls");
        cout<<"Unvalid equation"<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
    }
    else
    {
        system("cls");
        if (b>0&&e>0)
        {
            cout<<a<<"x+"<<b<<"y="<<c<<endl;
            cout<<d<<"x+"<<e<<"y="<<f<<endl;
        }
        else if (b>0&&e<0)
        {
            cout<<a<<"x+"<<b<<"y="<<c<<endl;
            cout<<d<<"x"<<e<<"y="<<f<<endl;
        }
        else if (b<0&&e>0)
        {
            cout<<a<<"x"<<b<<"y="<<c<<endl;
            cout<<d<<"x+"<<e<<"y="<<f<<endl;
        }
        else if (b<0&&e<0)
        {
            cout<<a<<"x"<<b<<"y="<<c<<endl;
            cout<<d<<"x"<<e<<"y="<<f<<endl;
        }
        else if (a==0&&d==0)
        {
            cout<<b<<"y="<<c<<endl;
            cout<<e<<"y="<<f<<endl;
        }
        else if (a==0&&e==0)
        {
            cout<<b<<"y="<<c<<endl;
            cout<<d<<"x="<<f<<endl;
        }
        else if (b==0&&d==0)
        {
            cout<<a<<"x="<<c<<endl;
            cout<<e<<"y="<<f<<endl;
        }
        else if (b==0&&e==0)
        {
            cout<<a<<"x="<<c<<endl;
            cout<<d<<"x="<<f<<endl;
        }
        cout<<"Point of intersection:"<<endl;
        cout<<"("<<((c*(e/b)-f)/(a*(e/b)-d))<<","<<((c*(d/a)-f)/(b*(d/a)-e))<<")"<<endl;
        cout<<endl;
        cout<<"Press SPACE to retry..."<<endl;
        cout<<"Press ESC to Quit..."<<endl;
        while (j!=0)
        {
            if (GetKeyState(VK_SPACE) & 0x8000)
            {
                goto input;
            }
            else if (GetKeyState(VK_ESCAPE) & 0x8000)
            {
                break;
            }
        }
        system("cls");
        cout<<"Thanks for using my product!"<<endl;
        Sleep(10000);
        }
    return 0;
}
