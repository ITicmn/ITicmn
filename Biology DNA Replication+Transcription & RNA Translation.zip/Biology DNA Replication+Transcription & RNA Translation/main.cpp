#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int i,j=1,cho,h=0;
    string gene,temp;
    start:
    system("cls");
    cout<<"Please choose the system you want"<<endl;
    cout<<"1.Gene Replication        2.Gene Transcription        3.Gene Translation"<<endl;
    cin>>cho;
    system("cls");
    if (cho==1)
    {
        cout<<"Please input your DNA"<<endl;
    }
    else if (cho==2)
    {
        cout<<"Please input your DNA"<<endl;
    }
    else if (cho==3)
    {
        cout<<"Please input your RNA"<<endl;
    }
    cin>>gene;
    temp=gene;
    if (cho==1)
    {
        for (i=0;i<gene.length();i++)
        {
            if (gene[i]==65)
            {
                temp[i]=84;
            }
            else if (gene[i]==84)
            {
                temp[i]=65;
            }
            else if (gene[i]==67)
            {
                temp[i]=71;
            }
            else if (gene[i]==71)
            {
                temp[i]=67;
            }
        }
        system("cls");
        cout<<"DNA Replication:"<<endl;
        cout<<"5'-"<<gene<<"-3'"<<endl;
        cout<<"3'-"<<temp<<"-5'"<<endl;
    }
    else if (cho==2)
    {
        for (i=0;i<gene.length();i++)
        {
            if (gene[i]==65)
            {
                temp[i]=85;
            }
            else if (gene[i]==84)
            {
                temp[i]=65;
            }
            else if (gene[i]==67)
            {
                temp[i]=71;
            }
            else if (gene[i]==71)
            {
                temp[i]=67;
            }
        }
        system("cls");
        cout<<"DNA Transcription:"<<endl;
        cout<<"3'-"<<gene<<"-5'"<<endl;
        cout<<"5'-"<<temp<<"-3'"<<endl;
    }
    else if (cho==3)
    {
        system("cls");
        cout<<"RNA Translation:"<<endl;
        cout<<"Input:"<<endl;
        cout<<gene<<endl;
        cout<<"Amino Acid:"<<endl;
        for (i=0;i!=gene.length();i=i+3)
        {
            if (gene[i]==65&&gene[i+1]==85&&gene[i+2]==71)
            {
                h=h+1;
            }
            if (gene[i]==85&&gene[i+1]==65&&gene[i+2]==65||gene[i]==85&&gene[i+1]==65&&gene[i+2]==71||gene[i]==85&&gene[i+1]==71&&gene[i+2]==65)
            {
                break;
            }
            if (h>0)
            {
                if (gene[i]==85&&gene[i+1]==85&&gene[i+2]==85||gene[i]==85&&gene[i+1]==85&&gene[i+2]==67)//
                {
                    cout<<"Phe"<<flush;
                }
                else if (gene[i]==85&&gene[i+1]==85&&gene[i+2]==65||gene[i]==85&&gene[i+1]==85&&gene[i+2]==71)//
                {
                    cout<<"Leu"<<flush;
                }
                else if (gene[i]==67&&gene[i+1]==85&&gene[i+2]==85||gene[i]==67&&gene[i+1]==85&&gene[i+2]==67||gene[i]==67&&gene[i+1]==85&&gene[i+2]==65||gene[i]==67&&gene[i+1]==85&&gene[i+2]==71)//
                {
                    cout<<"Leu"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==85&&gene[i+2]==85||gene[i]==65&&gene[i+1]==85&&gene[i+2]==67 || gene[i]==65&&gene[i+1]==85&&gene[i+2]==65)//
                {
                    cout<<"IIe"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==85&&gene[i+2]==71)//
                {
                    cout<<"Met"<<flush;
                }
                else if (gene[i]==71&&gene[i+1]==85&&gene[i+2]==85||gene[i]==71&&gene[i+1]==85&&gene[i+2]==67||gene[i]==71&&gene[i+1]==85&&gene[i+2]==65||gene[i]==71&&gene[i+1]==85&&gene[i+2]==71)//
                {
                    cout<<"Val"<<flush;
                }
                else if (gene[i]==85&&gene[i+1]==67&&gene[i+2]==85||gene[i]==85&&gene[i+1]==67&&gene[i+2]==67||gene[i]==85&&gene[i+1]==67&&gene[i+2]==65||gene[i]==85&&gene[i+1]==67&&gene[i+2]==71)//
                {
                    cout<<"Ser"<<flush;
                }
                else if (gene[i]==67&&gene[i+1]==67&&gene[i+2]==85||gene[i]==67&&gene[i+1]==67&&gene[i+2]==67||gene[i]==67&&gene[i+1]==67&&gene[i+2]==65||gene[i]==67&&gene[i+1]==67&&gene[i+2]==71)//
                {
                    cout<<"Pro"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==67&&gene[i+2]==85||gene[i]==65&&gene[i+1]==67&&gene[i+2]==67||gene[i]==65&&gene[i+1]==67&&gene[i+2]==65||gene[i]==65&&gene[i+1]==67&&gene[i+2]==71)//
                {
                    cout<<"Thr"<<flush;
                }
                else if (gene[i]==71&&gene[i+1]==67&&gene[i+2]==85||gene[i]==71&&gene[i+1]==67&&gene[i+2]==67||gene[i]==71&&gene[i+1]==67&&gene[i+2]==65||gene[i]==71&&gene[i+1]==67&&gene[i+2]==71)//
                {
                    cout<<"Ala"<<flush;
                }
                else if (gene[i]==85&&gene[i+1]==65&&gene[i+2]==85||gene[i]==85&&gene[i+1]==65&&gene[i+2]==67)//
                {
                    cout<<"Tyr"<<flush;
                }
                else if (gene[i]==67&&gene[i+1]==65&&gene[i+2]==85||gene[i]==67&&gene[i+1]==65&&gene[i+2]==67)//
                {
                    cout<<"His"<<flush;
                }
                else if (gene[i]==67&&gene[i+1]==65&&gene[i+2]==65||gene[i]==67&&gene[i+1]==65&&gene[i+2]==71)//
                {
                    cout<<"Gln"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==65&&gene[i+2]==85||gene[i]==65&&gene[i+1]==65&&gene[i+2]==67)//
                {
                    cout<<"Asn"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==65&&gene[i+2]==65||gene[i]==65&&gene[i+1]==65&&gene[i+2]==71)//
                {
                    cout<<"Lys"<<flush;
                }
                else if (gene[i]==71&&gene[i+1]==65&&gene[i+2]==85||gene[i]==71&&gene[i+1]==65&&gene[i+2]==67)//
                {
                    cout<<"Asp"<<flush;
                }
                else if (gene[i]==71&&gene[i+1]==65&&gene[i+2]==65||gene[i]==71&&gene[i+1]==65&&gene[i+2]==71)//
                {
                    cout<<"Glu"<<flush;
                }
                else if (gene[i]==85&&gene[i+1]==71&&gene[i+2]==85||gene[i]==85&&gene[i+1]==71&&gene[i+2]==67)//
                {
                    cout<<"Cys"<<flush;
                }
                else if (gene[i]==85&&gene[i+1]==71&&gene[i+2]==71)
                {
                    cout<<"Trp"<<flush;
                }
                else if (gene[i]==67&&gene[i+1]==71&&gene[i+2]==85||gene[i]==67&&gene[i+1]==71&&gene[i+2]==67||gene[i]==67&&gene[i+1]==71&&gene[i+2]==65||gene[i]==67&&gene[i+1]==71&&gene[i+2]==71)//
                {
                    cout<<"Arg"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==71&&gene[i+2]==85||gene[i]==65&&gene[i+1]==71&&gene[i+2]==67)//
                {
                    cout<<"Ser"<<flush;
                }
                else if (gene[i]==65&&gene[i+1]==71&&gene[i+2]==65||gene[i]==65&&gene[i+1]==71&&gene[i+2]==71)//
                {
                    cout<<"Arg"<<flush;
                }
                else if (gene[i]==71&&gene[i+1]==71&&gene[i+2]==85||gene[i]==71&&gene[i+1]==71&&gene[i+2]==67||gene[i]==71&&gene[i+1]==71&&gene[i+2]==65||gene[i]==71&&gene[i+1]==71&&gene[i+2]==71)//
                {
                    cout<<"Gly"<<flush;
                }
                else//UAA UAG UGA
                {
                    break;
                }
                if (gene[i+3]==85&&gene[i+4]==65&&gene[i+5]==65||gene[i+3]==85&&gene[i+4]==65&&gene[i+5]==71||gene[i+3]==85&&gene[i+4]==71&&gene[i+5]==65)
                {
                    cout<<flush;
                }
                else
                {
                    cout<<"-"<<flush;
                }
            }
        }
    }
    cout<<endl;
    cout<<"Press SPACE to retry..."<<endl;
    cout<<"Press ESC to Quit..."<<endl;
    while (j!=0)
    {
        if (GetKeyState(VK_SPACE) & 0x8000)
        {
            h=0;
            goto start;
        }
        else if (GetKeyState(VK_ESCAPE) & 0x8000)
        {
            break;
        }
    }
    system("cls");
    cout<<"Thanks for using my product!"<<endl;
    Sleep(10000);
    return 0;
}
