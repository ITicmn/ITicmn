#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int n,p=0;
    cin>>n;
    n=n-1;
    int a[n],i,j,l,temp=0,f[p];
    for (i=0;i<=n;i++)
    {
        cin>>a[i];
    }
    for (i=0;i<=n;i++)
    {
        temp=0;
        for (l=0;l<i;l++)
        {
            if (a[i]==a[l])
            {
                temp=1;
            }
        }
        if (temp==1)
        {
            continue;
        }
        if (a[i]==2)
        {
            f[p]=2;
            p++;
        }
        else
        {
            for (j=2;j<a[i];j++)
            {
                if (j!=(a[i]-1))
                {
                    if (a[i]%j==0)
                    {
                        break;
                    }
                    continue;
                }
                else
                {
                    f[p]=a[i];
                    p++;
                    break;
                }
            }
        }
    }
    cout<<"Prime Numbers:"<<endl;
    for (i=0;i<p;i++)
    {
        for (j=0;j<i;j++)
        {
            if (f[j]>f[j+1])
            {
                swap(f[j+1],f[j]);
            }
        }
    }
    for (i=0;i<p;i++)
    {
        cout<<f[i]<<" ";
    }
    return 0;
}
