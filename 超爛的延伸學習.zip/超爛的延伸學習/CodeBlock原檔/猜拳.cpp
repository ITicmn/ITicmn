#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int a,o;
    srand(time(NULL)+getpid());
    cout<<"Welcome to Rock Paper Scissors!"<<endl;
    Sleep(1000);
    cout<<"Your opponent is me!"<<endl;
    Sleep(1000);
    cout<<"Start?"<<endl;
    system("pause");
    system("cls");
    cout<<"1:Rock 2:Paper 3:Scissors"<<endl;
    Sleep(1000);
    cout<<"Rock! ";
    Sleep(1000);
    cout<<"Paper! ";
    Sleep(1000);
    cout<<"Scissors!"<<endl;
    while (cin>>a)
    {
    o=rand()%(4-1)+1;
    if (a==1 && o==1)
    {
        cout<<"1!"<<endl;
        Sleep(400);
        cout<<"Tie?!"<<endl;
        Sleep(900);
    }
    else if (a==1 && o==2)
    {
        cout<<"2!"<<endl;
        Sleep(400);
        cout<<"Haha!I win!"<<endl;
        Sleep(900);
    }
    else if (a==1 && o==3)
    {
        cout<<"3!"<<endl;
        Sleep(400);
        cout<<"Huh?!I lost..."<<endl;
        Sleep(900);
    }
    else if (a==2 && o==1)
    {
        cout<<"1!"<<endl;
        Sleep(400);
        cout<<"Huh?!I lost..."<<endl;
        Sleep(900);
    }
    else if (a==2 && o==2)
    {
        cout<<"2!"<<endl;
        Sleep(400);
        cout<<"Tie?!"<<endl;
        Sleep(900);
    }
    else if (a==2 && o==3)
    {
        cout<<"3!"<<endl;
        Sleep(400);
        cout<<"Haha!I win!"<<endl;
        Sleep(900);
    }
    else if (a==3 && o==1)
    {
        cout<<"1!"<<endl;
        Sleep(400);
        cout<<"Haha!I win!"<<endl;
        Sleep(900);
    }
    else if (a==3 && o==2)
    {
        cout<<"2!"<<endl;
        Sleep(400);
        cout<<"Huh?!I lost..."<<endl;
        Sleep(900);
    }
    else if (a==3 && o==3)
    {
        cout<<"3!"<<endl;
        Sleep(400);
        cout<<"Tie?!"<<endl;
        Sleep(900);
    }
    system("cls");
    }


    return 0;
}