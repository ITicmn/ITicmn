#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int e,y,score=0,h=1;
    srand(time(NULL)+getpid());
    e=rand()%(101-1)+1;
    while (h!=10)
    {
        e=rand()%(101-1)+1;
        cin>>y;
            if (e<y)
            {
                cout<<"You're smaller"<<endl;
                score=score-1;
            }
            else if (y>e)
            {
                cout<<"You're bigger"<<endl;
                score=score+1;
            }
            else
            {
                cout<<"Tie"<<endl;
            }
            Sleep(1000);
            system("cls");
            h=h+1;
    }
    cout<<"Score:"<<score<<endl;
    Sleep(1000000000);
    return 0;

}