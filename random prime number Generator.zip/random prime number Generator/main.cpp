#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main()
{
    int n,b,s;
    cout<<"How many prime number you want?"<<endl;
    srand(time(NULL)+getpid());
    cin>>n;
    n=n-1;
    system("cls");
    cout<<"The interval?"<<endl;
    cin>>b>>s;
    if (b<s)
    {
        swap(b,s);
    }
    int a,g[n],m=0,i=0,j,l;
    random:
    while (m<=n)
    {
        a=rand()%(b+1-s)+s;
        for (j=0;j<i;j++)
        {
            if (a==g[j])
            {
                goto random;
            }
        }
        if (a==2)
        {
            g[i]=2;
            i=i+1;
            m=m+1;
            goto random;
        }
        else
        {
            for (j=2;j<a;j++)
            {
                if (j!=(a-1))
                {
                    if (a%j==0)
                    {
                        goto random;
                    }
                    continue;
                }
                else
                {
                    g[i]=a;
                    i=i+1;
                    m=m+1;
                    break;
                }
            }
        }
    }
    for (l=0;l<=n;l++)
    {
        for (j=0;j<n;j++)
        {
            if (g[j]>g[j+1])
            {
                swap(g[j],g[j+1]);
            }
        }
    }
    for (j=0;j<=n;j++)
    {
        cout<<g[j]<<" "<<flush;
    }
    Sleep(100000);
    return 0;
}
